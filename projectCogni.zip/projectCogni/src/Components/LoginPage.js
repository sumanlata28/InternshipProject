import React, { useState } from 'react';
import { useHistory } from 'react-router-dom';

const LoginPage = () => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const history = useHistory();

  const handleLogin = () => {
    if ((username === 'Suman' && password === '1234') ||(username === 'Rajeev' && password === '1234') ) {
      // Navigate to the student registration page
      history.push('./Components/home');
    } else {
      alert('Invalid username or password');
    }
  };

  return (
    <div className="bground">
    <div className="container">
        <center><h1>Student Management System</h1></center>
        <br/>
      <center><h2>Admin Login Page</h2>
      <img className="logo-image" src="https://www.kindpng.com/picc/m/227-2271076_student-management-system-symbol-hd-png-download.png" alt="Student_Management _System_Symbol"></img>
      </center>
      <br/>
      <form onSubmit={handleLogin}>
        <div className="form-group">
          <label htmlFor="username"><b>Username:</b></label>
          <input
            type="text"
            className="form-control"
            id="username"
            value={username}
            onChange={(e) => setUsername(e.target.value)}
          />
        </div>
        <div className="form-group">
          <label htmlFor="password"><b>Password:</b></label>
          <input
            type="password"
            className="form-control"
            id="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
          />
        </div>
        <button type="submit" className="btn btn-primary">Login</button>
      </form>
    </div>
    <br/><br/><br/><br/><br/><br/>
    </div>
  );
};

export default LoginPage;
