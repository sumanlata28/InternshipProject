import React from "react";

 
const HomePage = () => {
 
  return (
    <div className="bground">
    <div className="container">
      <div className="text-center">
        <h2>Hi Admin WelCome to Homepage</h2>
        <img className="logo-image2" src="https://rtosoftware.eskilled.com.au/wp-content/uploads/2022/05/The-Best-Student-Management-System-in-Australia-image.svg"></img>
        <h1 className="display-4">Student Management System</h1>
        <p className="lead">
          In this student management system software which is used in coaching classes for registering student detail.
        </p>
        <a href="Student" className="btn btn-primary">Go to Student Registration</a>
      </div>
        <br/>
      <div className="jumbotron">
        <center>
          <h1>Project By:</h1>
        </center>
        <p className="lead">
          <h3><b>Owner:</b>   Suman Lata</h3>
          <h3><b>Employee ID:</b>   2266590</h3>
          <h3><b> Comapny Name:</b> Cognizant Private Limited</h3>
        </p>
      </div>
      <center>
        <div className="btn-group">
         
          <a href="/" className="btn btn-primary">Log out</a>
         
        </div>
      </center>
    </div>
    </div>
  );
};
 
export default HomePage;