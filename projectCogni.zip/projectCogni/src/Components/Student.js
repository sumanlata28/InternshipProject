import React, { useState, useEffect } from 'react';
import axios from 'axios';


const Student = () => {
  const [students, setStudents] = useState([]);
  const [firstname, setFirstName] = useState('');
  const [lastname, setLastName] = useState('');
  const [branch, setBranch] = useState('');
  const [contact, setContact] = useState('');
  const [address, setAddress] = useState('');
  const [score, setScore] = useState('');

  useEffect(() => {
    fetchStudents();
  }, []);

  const fetchStudents = async () => {
    try {
      const response = await axios.get('https://localhost:7219/api/Students');
      setStudents(response.data);
    } catch (error) {
      console.error(error);
    }
  };

  const registerStudent = async () => {
    const studentData = {
      firstname: firstname,
      lastname: lastname,
      branch: branch,
      contact:contact,
      address: address,
      score: score
    };

    try {
      await axios.post('https://localhost:7219/api/Students', studentData);
      setFirstName('');
      setLastName('');
      setBranch('');
      setContact('');
      setAddress('');
      setScore('');
      fetchStudents();
    } catch (error) {
      console.error(error);
    }
  };


//   const updateStudent = async (id) => {
//   const studentToUpdate = students.find(student => student.id === id);

//   if (!studentToUpdate) {
//     console.error(`Student with ID ${id} not found`);
//     return;
//   }

//   setFirstName(studentToUpdate.firstname);
//   setLastName(studentToUpdate.lastname);
//   setBranch(studentToUpdate.branch);
//   setContact(studentToUpdate.contact);
//   setAddress(studentToUpdate.address);
//   setScore(studentToUpdate.score);

//   try {
//     await axios.put(`https://localhost:7219/api/Students/${id}`, {
//       firstname,
//       lastname,
//       branch,
//       contact,
//       address,
//       score
//     });

//     // Clear the form after successful update
//     setFirstName('');
//     setLastName('');
//     setBranch('');
//     setContact('');
//     setAddress('');
//     setScore('');

//     fetchStudents();
//   } catch (error) {
//     console.error(error);
//   }
// };

const updateStudent = async (inputData) => {
  console.log(inputData)
 let id=inputData.id;
  const studentToUpdate = students.find(student => student.id === id);

  if (!studentToUpdate) {
    console.error(`Student with ID ${id} not found`);
    return;
  }
console.log(studentToUpdate);
  setFirstName(studentToUpdate.firstname);
  setLastName(studentToUpdate.lastname);
  setBranch(studentToUpdate.branch);
  setContact(studentToUpdate.contact);
  setAddress(studentToUpdate.address);
  setScore(studentToUpdate.score);

  try {
    await axios.put(`https://localhost:7219/api/Students/${id}`, {
     id:studentToUpdate.id, 
    firstname:inputData.firstname,
      lastname:inputData.lastname,
      branch:inputData.branch,
      contact:inputData.contact,
      address:inputData.address,
      score:inputData.score
    });

    // Clear the form after successful update
    setFirstName('');
    setLastName('');
    setBranch('');
    setContact('');
    setAddress('');
    setScore('');

    return fetchStudents(); // Update the student list with the updated data
  } catch (error) {
    console.error(error);
  }
};



  const deleteStudent = async (id) => {
    try {
      await axios.delete(`https://localhost:7219/api/Students/${id}`);
      fetchStudents();
    } catch (error) {
      console.error(error);
    }
  };

  return (
    <div className='bground'>
    <div className="container"  >
      <div className="btn-group">
        <a href="/" className="btn btn-primary">Log out</a>
        
      </div>
      <h1  className="text-danger fw-bold text-center" style={{ textDecoration: 'underline' }}> Student Management System</h1><br/>
      <h3  className= "text-success fw-bold text-center" style={{ textDecoration: 'underline'}}>Student Registration Form</h3><br/>
      <h4 >Fill the Below details corretcly.......</h4><br/>
     
      <form>
        <div className="mb-3">
          <label className="form-label font-weight-bold font-italic text-black ">1.  Enter Student's First Name:</label>
          <input className="form-control"  value={firstname} onChange={(e) => setFirstName(e.target.value)} required />
        </div>
        <div className="mb-3">
          <label className="form-label font-weight-bold font-italic text-black ">2.   Enter Student's Last Name:</label>
          <input className="form-control" type="text" value={lastname} onChange={(e) => setLastName(e.target.value) }required  />
        </div>
        <div className="mb-3">
          <label className="form-label font-weight-bold font-italic text-black "> 3.  Enter Student's Branch:</label>
          <input className="form-control" type="text" value={branch} onChange={(e) => setBranch(e.target.value)} />
        </div>
        <div className="mb-3">
          <label className="form-label font-weight-bold font-italic text-black "> 4. Enter Student's Contact No :</label>
          <input className="form-control" type="text" value={contact} onChange={(e) => setContact(e.target.value)} />
        </div>
        <div className="mb-3">
          <label className="form-label font-weight-bold font-italic text-black "> 5. Enter Student's Permanent Contact Address:</label>
          <input className="form-control" type="text" value={address} onChange={(e) => setAddress(e.target.value)} />
        </div>
        <div className="mb-3">
          <label className="form-label font-weight-bold font-italic text-black ">6.  Enter Student's Score:</label>
          <input className="form-control" type="text" value={score} onChange={(e) => setScore(e.target.value)}required  />
        </div>
        <button className="btn btn-primary" type="button" onClick={registerStudent}>Register</button>
      </form>

      <h2>Student Details</h2>
      <table className="table">
        <thead>
          <tr>
            <th>ID</th>
            <th>First Name</th>
            <th>Last Name</th>
            <th>Branch</th>
            <th>Contact</th>
              <th> Address</th>
            <th>Score</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {students.map((student) => (
            <tr key={student.id}>
              <td>{student.id}</td>
              <td>{student.firstname}</td>
              <td>{student.lastname}</td>
              <td>{student.branch}</td>
              <td>{student.contact}</td>
              <td>{student.address}</td>
              <td>{student.score}</td>
              <td>
                <button className="btn btn-sm btn-primary" onClick={() => updateStudent(student)}>Update</button>
                <button className="btn btn-sm btn-danger" onClick={() => deleteStudent(student.id)}>Delete</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
    </div>
  );
};

export default Student;
