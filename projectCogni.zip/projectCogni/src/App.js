import React from 'react';
import { BrowserRouter as Router, Route, Switch, Redirect } from 'react-router-dom';
import Student from './Components/Student';
import LoginPage from './Components/LoginPage';
import HomePage from './Components/home';
const App = () => {
  return (
    <Router>
      <Switch>
        <Route exact path="/" component={LoginPage} />
        <Route path="/Components/Student" component={Student} />
        <Route path="/Components/home" component={HomePage} />
      </Switch>
    </Router>
  );
};

export default App;
